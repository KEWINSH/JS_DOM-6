function Colorchangern0() {
    document.body.style.backgroundColor = "Purple";
    document.getElementById("yes").style.color = "white";
    document.getElementById("yes").style.fontWeight = "bolder";
}

function Colorchangern01() {
    document.body.style.backgroundColor = "Blue";
    document.getElementById("yes").style.color = "white";
    document.getElementById("yes").style.fontWeight = "bolder";
}

function Colorchangern02() {
    document.body.style.backgroundColor = "Red";
    document.getElementById("yes").style.color = "white";
    document.getElementById("yes").style.fontWeight = "bolder";
}

function Colorchangern03() {
    document.body.style.backgroundColor = "Green";
    document.getElementById("yes").style.color = "white";
    document.getElementById("yes").style.fontWeight = "bolder";
}

function Colorchangern04() {
    document.body.style.backgroundColor = "Yellow";
    document.getElementById("yes").style.color = "white";
    document.getElementById("yes").style.fontWeight = "bolder";
}

function Colorchangern05() {
    document.body.style.backgroundColor = "White";
    document.getElementById("yes").style.color = "black";
    document.getElementById("yes").style.fontWeight = "bolder";
}